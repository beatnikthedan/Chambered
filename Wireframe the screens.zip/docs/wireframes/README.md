# Chambered — screen wireframes

`chambered-wireframes.html` is a self-contained page (no build step, no external
assets, works offline). Open it in any browser.

Covers the routes that currently render `PlaceholderView`, drawn inside a
recreation of the live app shell (`src/App.jsx` + `src/App.css` + `src/style.css`):

| id | Screen |
| --- | --- |
| 1a | Bench → Load Data — recipe table + work-up detail rail |
| 1b | Bench → Components — tabbed inventory (powders/primers/projectiles/brass/cartridges), inline quick-add |
| 1c | Range → Trips — trip list, per-trip conditions header, string-by-string log |
| 1d | Range → Targets — card grid, drop-to-upload, group size in MOA |
| 1e | Range → Training — drill library, progression chart, session log |
| 1f | Armory → Maintenance Log — per-firearm round counts, history table, log panel |
| 1g | Dashboard — proposed **Munitions** block under the Armory heading |

## Design decisions carried across the set

- **Inline entry, not modals.** The primary job is data entry and inventory
  management, so every screen has an inline add row or a persistent side panel.
- **Tables for numbers, cards only where the record is visual.** Load data,
  components, maintenance and sessions are tables; targets are cards because the
  photo *is* the record; munitions are cards because they are rollups.
- **No new sidebar routes.** Components is tabs within one route; Munitions is a
  dashboard block, not a route.
- **Derived values are never typed twice.** Round counts flow range strings →
  maintenance counters; saving a string draws down its ammo lot; a recipe's
  "make ammo lot" action creates the munitions record.

Gold handwritten notes on each screen call out the specific rationale.
