# Chambered — screen wireframes

`chambered-wireframes.html` is a self-contained page (no build step, no external
assets, works offline). Open it in any browser. Newest work is at the top.

## Turn 2 — redesign of the shipping views

| id | Screen |
| --- | --- |
| 2a | Dashboard — readiness strip + "needs attention" queue replace the 4-stat-card row |
| 2b | Armory — table + persistent detail rail instead of card grid + modal |
| 2c | Vaults — capacity list with contents table; tree view folded in |
| 2d | Catalog — type tabs with counts, dense table, spec drawer |
| 2e | Settings — vertical section nav replaces the 4 top tabs |
| 2f | Login — normal sign-in and first-run setup, side by side |

Shared thesis:

- **One page frame everywhere.** Title + state subtitle, actions top-right, one
  toolbar row, then content. No per-view divergence.
- **No repeated stat-card rows.** Numbers live in a single dense strip with a
  state line under each, freeing the page for what needs doing.
- **Table-first, detail rail second.** Modals are retired; the rail is the same
  interaction model as the Bench screens in turn 1.
- **Real icon set.** Nav glyphs are `ARSENAL_ICONS` paths verbatim
  (`activity`, `briefcase`, `tool`, `target`, `lock`, `book`, `key`, `shield`);
  the emoji flame is gone.

## Turn 1 — the routes still rendering `PlaceholderView`

Drawn inside a recreation of the current app shell (`src/App.jsx` +
`src/App.css` + `src/style.css`), so these read as additions to today's UI.

| id | Screen |
| --- | --- |
| 1a | Bench → Load Data — recipe table + work-up detail rail |
| 1b | Bench → Components — tabbed inventory, inline quick-add |
| 1c | Range → Trips — trip list, conditions header, string-by-string log |
| 1d | Range → Targets — card grid, drop-to-upload, group size in MOA |
| 1e | Range → Training — drill library, progression chart, session log |
| 1f | Armory → Maintenance Log — round counts, history table, log panel |
| 1g | Dashboard — proposed **Munitions** block under the Armory heading |

Decisions carried across the set:

- **Inline entry, not modals.** The primary job is data entry and inventory
  management, so every screen has an inline add row or a persistent side panel.
- **Tables for numbers, cards only where the record is visual.** Targets are
  cards because the photo *is* the record; munitions are cards because they are
  rollups. Everything else is a table.
- **No new sidebar routes.** Components is tabs within one route; Munitions is a
  dashboard block.
- **Derived values are never typed twice.** Round counts flow range strings →
  maintenance counters; saving a string draws down its ammo lot; a recipe's
  "make ammo lot" action creates the munitions record.

Gold handwritten notes on each screen call out the specific rationale.
